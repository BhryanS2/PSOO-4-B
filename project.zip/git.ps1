# submit to github
# git add .
# git commit -m "commit message"
# git push origin master

git add .
git commit -m "commit message"
git push origin master
