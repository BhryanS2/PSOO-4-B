# zip files and exlude .git directory
zip -r project.zip . -x .git/\*