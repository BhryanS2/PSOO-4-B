<?php
// Array ( [0] => lesson [1] => getall );
// $uri = array(0 => "lesson", 1 => "getall");
// $uriJoin = implode("/", $uri);
// print_r($uriJoin);

exec("php -S localhost:8000");
